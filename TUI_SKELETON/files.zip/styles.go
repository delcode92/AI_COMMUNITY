package ui

import "github.com/charmbracelet/lipgloss"

// opencode-inspired color palette
const (
	colorBg       = "#0d0f11"
	colorBgPanel  = "#13161a"
	colorBorder   = "#2a2d35"
	colorGreen    = "#4dfa7b"
	colorTeal     = "#2dd4bf"
	colorMuted    = "#4a5568"
	colorText     = "#e2e8f0"
	colorSubtle   = "#718096"
	colorUser     = "#63b3ed"
	colorError    = "#fc8181"
	colorWaiting  = "#f6e05e"
)

var (
	// Status bar at the bottom
	StatusBarStyle = lipgloss.NewStyle().
			Background(lipgloss.Color(colorBgPanel)).
			Foreground(lipgloss.Color(colorMuted)).
			Padding(0, 1)

	StatusKeyStyle = lipgloss.NewStyle().
			Background(lipgloss.Color(colorBgPanel)).
			Foreground(lipgloss.Color(colorGreen)).
			Bold(true)

	StatusModelStyle = lipgloss.NewStyle().
				Background(lipgloss.Color(colorBgPanel)).
				Foreground(lipgloss.Color(colorTeal))

	// Chat messages
	UserLabelStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorUser)).
			Bold(true)

	AssistantLabelStyle = lipgloss.NewStyle().
				Foreground(lipgloss.Color(colorGreen)).
				Bold(true)

	ErrorStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorError))

	WaitingStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorWaiting))

	MessageStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorText))

	SubtleStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorSubtle))

	// Input area
	InputBorderStyle = lipgloss.NewStyle().
				Border(lipgloss.RoundedBorder()).
				BorderForeground(lipgloss.Color(colorBorder)).
				Padding(0, 1)

	InputFocusedBorderStyle = lipgloss.NewStyle().
				Border(lipgloss.RoundedBorder()).
				BorderForeground(lipgloss.Color(colorGreen)).
				Padding(0, 1)

	// Divider
	DividerStyle = lipgloss.NewStyle().
			Foreground(lipgloss.Color(colorBorder))
)
